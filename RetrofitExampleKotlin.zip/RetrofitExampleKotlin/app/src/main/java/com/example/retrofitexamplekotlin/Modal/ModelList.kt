package com.example.retrofitexamplekotlin.Modal

class ModelList : ArrayList<ModelListItem>()